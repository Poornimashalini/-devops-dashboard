import requests
import json
import os
from datetime import datetime, timedelta
import logging
import random
from .base_adapter import BaseCloudAdapter

class AzureAdapter(BaseCloudAdapter):
    """Adapter for Azure deployments"""
    
    def __init__(self):
        super().__init__("azure")
        self.api_key = os.getenv("AZURE_API_KEY", "")
        self.api_base_url = os.getenv("AZURE_API_URL", "")
        self.subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID", "")
    
    def get_deployments(self):
        """
        Get deployments from Azure DevOps or other deployment services.
        
        In a real implementation, this would call Azure APIs to get actual deployment data.
        """
        try:
            # This would be a real API call to Azure in production
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/deployments",
                    headers=headers
                )
                
                if response.status_code == 200:
                    deployments = response.json().get("value", [])
                    return [self.format_deployment(dep) for dep in deployments]
                else:
                    logging.error(f"Azure API error: {response.status_code} - {response.text}")
                    return []
            else:
                # If no API credentials are provided, return an empty list
                logging.warning("No Azure API credentials provided")
                return []
                
        except Exception as e:
            return self.handle_api_error(e)
    
    def get_deployment_logs(self, deployment_id):
        """Get logs for a specific Azure deployment"""
        try:
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/deployments/{deployment_id}/logs",
                    headers=headers
                )
                
                if response.status_code == 200:
                    return response.json().get("logs", "No logs available")
                else:
                    logging.error(f"Azure API error: {response.status_code} - {response.text}")
                    return "Error retrieving logs"
            else:
                return "No Azure API credentials provided"
        except Exception as e:
            logging.error(f"Error getting Azure deployment logs: {str(e)}")
            return f"Error retrieving logs: {str(e)}"
    
    def format_deployment(self, raw_deployment):
        """Format raw Azure deployment data into standardized format"""
        # In a real implementation, this would convert Azure-specific fields to our standard format
        
        # Example of standardized deployment format
        return {
            "id": raw_deployment.get("id", ""),
            "name": raw_deployment.get("name", ""),
            "platform": "azure",
            "environment": raw_deployment.get("targetEnvironment", ""),
            "status": self._map_status(raw_deployment.get("status", "")),
            "start_time": raw_deployment.get("startTime", ""),
            "end_time": raw_deployment.get("finishTime", ""),
            "logs": raw_deployment.get("logs", ""),
            "metadata": {
                "reason": raw_deployment.get("reason", ""),
                "requestedBy": raw_deployment.get("requestedBy", {}),
                "project": raw_deployment.get("project", {})
            }
        }
    
    def _map_status(self, azure_status):
        """Map Azure specific statuses to our standard statuses"""
        status_mapping = {
            "notDeployed": "Pending",
            "inProgress": "Running",
            "succeeded": "Success",
            "partiallySucceeded": "Success",
            "failed": "Failed",
            "all": "Unknown"
        }
        return status_mapping.get(azure_status, azure_status)
