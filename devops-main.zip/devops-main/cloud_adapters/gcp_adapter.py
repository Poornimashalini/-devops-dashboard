import requests
import json
import os
from datetime import datetime, timedelta
import logging
import random
from .base_adapter import BaseCloudAdapter

class GCPAdapter(BaseCloudAdapter):
    """Adapter for Google Cloud Platform deployments"""
    
    def __init__(self):
        super().__init__("gcp")
        self.api_key = os.getenv("GCP_API_KEY", "")
        self.api_base_url = os.getenv("GCP_API_URL", "")
        self.project_id = os.getenv("GCP_PROJECT_ID", "")
    
    def get_deployments(self):
        """
        Get deployments from Google Cloud Build or other deployment services.
        
        In a real implementation, this would call GCP APIs to get actual deployment data.
        """
        try:
            # This would be a real API call to GCP in production
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/projects/{self.project_id}/builds",
                    headers=headers
                )
                
                if response.status_code == 200:
                    deployments = response.json().get("builds", [])
                    return [self.format_deployment(dep) for dep in deployments]
                else:
                    logging.error(f"GCP API error: {response.status_code} - {response.text}")
                    return []
            else:
                # If no API credentials are provided, return an empty list
                logging.warning("No GCP API credentials provided")
                return []
                
        except Exception as e:
            return self.handle_api_error(e)
    
    def get_deployment_logs(self, deployment_id):
        """Get logs for a specific GCP deployment"""
        try:
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/projects/{self.project_id}/builds/{deployment_id}/logs",
                    headers=headers
                )
                
                if response.status_code == 200:
                    return response.json().get("logs", "No logs available")
                else:
                    logging.error(f"GCP API error: {response.status_code} - {response.text}")
                    return "Error retrieving logs"
            else:
                return "No GCP API credentials provided"
        except Exception as e:
            logging.error(f"Error getting GCP deployment logs: {str(e)}")
            return f"Error retrieving logs: {str(e)}"
    
    def format_deployment(self, raw_deployment):
        """Format raw GCP deployment data into standardized format"""
        # In a real implementation, this would convert GCP-specific fields to our standard format
        
        # Example of standardized deployment format
        return {
            "id": raw_deployment.get("id", ""),
            "name": raw_deployment.get("name", ""),
            "platform": "gcp",
            "environment": raw_deployment.get("tags", {}).get("environment", ""),
            "status": self._map_status(raw_deployment.get("status", "")),
            "start_time": raw_deployment.get("startTime", ""),
            "end_time": raw_deployment.get("finishTime", ""),
            "logs": raw_deployment.get("logUrl", ""),
            "metadata": {
                "createTime": raw_deployment.get("createTime", ""),
                "creator": raw_deployment.get("creator", ""),
                "images": raw_deployment.get("images", [])
            }
        }
    
    def _map_status(self, gcp_status):
        """Map GCP specific statuses to our standard statuses"""
        status_mapping = {
            "QUEUED": "Pending",
            "WORKING": "Running",
            "SUCCESS": "Success",
            "FAILURE": "Failed",
            "INTERNAL_ERROR": "Failed",
            "TIMEOUT": "Failed",
            "CANCELLED": "Failed",
            "EXPIRED": "Failed"
        }
        return status_mapping.get(gcp_status, gcp_status)
