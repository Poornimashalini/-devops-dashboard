import requests
import json
import os
from datetime import datetime, timedelta
import logging
import random
from .base_adapter import BaseCloudAdapter

class AWSAdapter(BaseCloudAdapter):
    """Adapter for AWS deployments"""
    
    def __init__(self):
        super().__init__("aws")
        self.api_key = os.getenv("AWS_API_KEY", "")
        self.api_base_url = os.getenv("AWS_API_URL", "")
        self.region = os.getenv("AWS_REGION", "us-east-1")
    
    def get_deployments(self):
        """
        Get deployments from AWS CodeDeploy or other deployment services.
        
        In a real implementation, this would call AWS APIs to get actual deployment data.
        """
        try:
            # This would be a real API call to AWS in production
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/deployments",
                    headers=headers
                )
                
                if response.status_code == 200:
                    deployments = response.json().get("deployments", [])
                    return [self.format_deployment(dep) for dep in deployments]
                else:
                    logging.error(f"AWS API error: {response.status_code} - {response.text}")
                    return []
            else:
                # If no API credentials are provided, return an empty list
                logging.warning("No AWS API credentials provided")
                return []
                
        except Exception as e:
            return self.handle_api_error(e)
    
    def get_deployment_logs(self, deployment_id):
        """Get logs for a specific AWS deployment"""
        try:
            if self.api_base_url and self.api_key:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                response = requests.get(
                    f"{self.api_base_url}/deployments/{deployment_id}/logs",
                    headers=headers
                )
                
                if response.status_code == 200:
                    return response.json().get("logs", "No logs available")
                else:
                    logging.error(f"AWS API error: {response.status_code} - {response.text}")
                    return "Error retrieving logs"
            else:
                return "No AWS API credentials provided"
        except Exception as e:
            logging.error(f"Error getting AWS deployment logs: {str(e)}")
            return f"Error retrieving logs: {str(e)}"
    
    def format_deployment(self, raw_deployment):
        """Format raw AWS deployment data into standardized format"""
        # In a real implementation, this would convert AWS-specific fields to our standard format
        
        # Example of standardized deployment format
        return {
            "id": raw_deployment.get("deploymentId", ""),
            "name": raw_deployment.get("applicationName", ""),
            "platform": "aws",
            "environment": raw_deployment.get("deploymentGroupName", ""),
            "status": self._map_status(raw_deployment.get("status", "")),
            "start_time": raw_deployment.get("createTime", ""),
            "end_time": raw_deployment.get("completeTime", ""),
            "logs": raw_deployment.get("logs", ""),
            "metadata": {
                "region": raw_deployment.get("region", self.region),
                "revision": raw_deployment.get("revision", {}),
                "creator": raw_deployment.get("creator", "")
            }
        }
    
    def _map_status(self, aws_status):
        """Map AWS specific statuses to our standard statuses"""
        status_mapping = {
            "Created": "Pending",
            "Queued": "Pending",
            "InProgress": "Running",
            "Succeeded": "Success",
            "Failed": "Failed",
            "Stopped": "Failed",
            "Ready": "Pending"
        }
        return status_mapping.get(aws_status, aws_status)
