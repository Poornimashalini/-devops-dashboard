from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List

@dataclass
class Deployment:
    """
    Represents a deployment across any cloud platform.
    This model standardizes deployment data from different sources.
    """
    id: str
    name: str
    platform: str
    environment: str
    status: str
    start_time: datetime
    end_time: Optional[datetime] = None
    logs: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def duration(self) -> Optional[float]:
        """
        Calculate deployment duration in seconds.
        Returns None if deployment is still running or time data is missing.
        """
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds()
        return None
    
    @property
    def is_active(self) -> bool:
        """Check if deployment is currently active"""
        return self.status == "Running"
    
    @property
    def is_successful(self) -> bool:
        """Check if deployment completed successfully"""
        return self.status == "Success"
    
    @property
    def is_failed(self) -> bool:
        """Check if deployment failed"""
        return self.status == "Failed"
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Deployment':
        """Create a Deployment instance from a dictionary"""
        # Convert string timestamps to datetime objects
        start_time = data.get('start_time')
        if isinstance(start_time, str):
            start_time = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        
        end_time = data.get('end_time')
        if isinstance(end_time, str) and end_time:
            end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        else:
            end_time = None
        
        return cls(
            id=data.get('id', ''),
            name=data.get('name', ''),
            platform=data.get('platform', ''),
            environment=data.get('environment', ''),
            status=data.get('status', ''),
            start_time=start_time,
            end_time=end_time,
            logs=data.get('logs', ''),
            metadata=data.get('metadata', {})
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert Deployment instance to a dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'platform': self.platform,
            'environment': self.environment,
            'status': self.status,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'logs': self.logs,
            'metadata': self.metadata
        }
