from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import pandas as pd

def aggregate_deployments(deployments: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aggregate deployment data to extract insights
    
    Args:
        deployments: List of deployment dictionaries
        
    Returns:
        A dictionary containing aggregated metrics
    """
    if not deployments:
        return {
            "total_count": 0,
            "success_count": 0,
            "failed_count": 0,
            "running_count": 0,
            "pending_count": 0,
            "success_rate": 0,
            "avg_duration": 0,
            "by_platform": {},
            "by_environment": {}
        }
        
    # Convert to dataframe for easier aggregation
    df = pd.DataFrame(deployments)
    
    # Count by status
    status_counts = df['status'].value_counts().to_dict()
    success_count = status_counts.get('Success', 0)
    failed_count = status_counts.get('Failed', 0)
    running_count = status_counts.get('Running', 0)
    pending_count = status_counts.get('Pending', 0)
    
    # Calculate success rate
    completed_count = success_count + failed_count
    success_rate = (success_count / completed_count * 100) if completed_count > 0 else 0
    
    # Calculate average duration for completed deployments
    completed_df = df[(df['status'] == 'Success') | (df['status'] == 'Failed')]
    
    avg_duration = 0
    if not completed_df.empty and 'start_time' in completed_df.columns and 'end_time' in completed_df.columns:
        # Convert string times to datetime if necessary
        if completed_df['start_time'].dtype == 'object':
            completed_df['start_time'] = pd.to_datetime(completed_df['start_time'])
        if completed_df['end_time'].dtype == 'object':
            completed_df['end_time'] = pd.to_datetime(completed_df['end_time'])
            
        # Calculate durations
        completed_df['duration'] = (completed_df['end_time'] - completed_df['start_time']).dt.total_seconds()
        avg_duration = completed_df['duration'].mean()
    
    # Group by platform and environment
    by_platform = df['platform'].value_counts().to_dict() if 'platform' in df.columns else {}
    by_environment = df['environment'].value_counts().to_dict() if 'environment' in df.columns else {}
    
    return {
        "total_count": len(deployments),
        "success_count": success_count,
        "failed_count": failed_count,
        "running_count": running_count,
        "pending_count": pending_count,
        "success_rate": success_rate,
        "avg_duration": avg_duration,
        "by_platform": by_platform,
        "by_environment": by_environment
    }

def filter_deployments(
    deployments: List[Dict[str, Any]],
    platforms: Optional[List[str]] = None,
    statuses: Optional[List[str]] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    environments: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Filter deployments based on various criteria
    
    Args:
        deployments: List of deployment dictionaries
        platforms: Optional list of platforms to include
        statuses: Optional list of statuses to include
        start_date: Optional start date for filtering
        end_date: Optional end date for filtering
        environments: Optional list of environments to include
        
    Returns:
        Filtered list of deployments
    """
    if not deployments:
        return []
    
    # Convert to DataFrame for easier filtering
    df = pd.DataFrame(deployments)
    
    # Apply platform filter
    if platforms and 'platform' in df.columns:
        df = df[df['platform'].isin(platforms)]
    
    # Apply status filter
    if statuses and 'status' in df.columns:
        df = df[df['status'].isin(statuses)]
    
    # Apply environment filter
    if environments and 'environment' in df.columns:
        df = df[df['environment'].isin(environments)]
    
    # Apply date filters
    if 'start_time' in df.columns:
        # Convert to datetime if it's not already
        if df['start_time'].dtype == 'object':
            df['start_time'] = pd.to_datetime(df['start_time'])
        
        if start_date:
            start_date = pd.to_datetime(start_date)
            df = df[df['start_time'] >= start_date]
        
        if end_date:
            end_date = pd.to_datetime(end_date)
            # Add one day to include the end date fully
            end_date = end_date + timedelta(days=1)
            df = df[df['start_time'] < end_date]
    
    # Convert back to list of dictionaries
    return df.to_dict(orient='records')
